class dirTreeNote():
    def __init__(self, par, data=None, subDirs=[]):
        self._data = data
        self._subDirs = list(subDirs)
        self._subDirs.append(par)

    def addDir(self, par, dirname):
        self._subDirs.append(dirTreeNote(par, dirname))

    @property
    def subDirs(self):
        return self._subDirs

    @property
    def data(self):
        return self._data

    def frontDir(self):
        return self._subDirs[0]

    def delete(self):
        self._data = None
        self._subDirs = None

    def removenone(self):
        self._subDirs = [x for x in self._subDirs if x.data is not None]

class dirTree():
    def __init__(self, root=dirTreeNote(None, '/')):
        self._root = root
        self._currentDir = self._root

    def mkdir(self, dirname):
        self._currentDir.addDir(self._currentDir, dirname)

    def lsdir(self):
        for x in self._currentDir.subDirs[1::]:
            print(x.data)

    def changeDir(self, dirname):
        if dirname == '..':
            self._currentDir = self._currentDir.frontDir()
            return
        for x in self._currentDir.subDirs[1::]:
            if x.data == dirname:
                self._currentDir = x
                break

        return False

    def _delDir(self, dirs):
        if dirs is not []:
            for x in dirs:
                if hasattr(x, 'subDirs'):
                    self._delDir(x.subDirs[1::])
                    x.removenone()
                else:
                    del x
        else:
            del dirs
    def delDir(self, dirname):
        for x in self._currentDir.subDirs[1::]:
            if x.data == dirname:
                if len(x.subDirs) <= 1:
                    x.delete()
                    self._currentDir.removenone()
                    return
                self._delDir(x.subDirs[1::])
                x.delete()
                self._currentDir.removenone()

            return

    def createDisk(self, diskname):
        diskname = diskname + ":/"
        self._root.addDir(self._root, diskname)

    def changeDisk(self, diskname):
        diskname = diskname + ':/'
        for x in self._root.subDirs:
            if hasattr(x, 'data'):
                if x.data == diskname:
                    self._currentDir = x
                    break
        return False

    def lsDisk(self):
        for x in self._root.subDirs[1::]:
            print(x.data)

    def pwd(self):
        workDir = self._currentDir.data
        temp = self._currentDir
        while temp.frontDir() is not None:
            temp = temp.frontDir()
            if temp.data is '/':
                break
            workDir = temp.data + '/'+workDir
        return workDir

