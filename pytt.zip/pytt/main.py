'''
为练习树结构而做的目录管理系统
@author Wangzhichen
time:2017.10
未做错误处理
未进行本地储存
'''

from time import sleep
from dirTree import dirTree

root = dirTree()


def init():
    pass
    # 初始化操作，以后可能会将树的信息存在本地。
    # print("正在获取目录信息...")
    # sleep(1)


def printMenu():
    print('欢迎使用文件管理器v0.1')
    print('1.列出磁盘')
    print('2.添加磁盘')
    print('3.切换磁盘')
    print('4.列出目录')
    print('5.添加目录')
    print('6.删除目录')
    print('7.当前所在目录')
    print('8.切换目录')
    print('9.退出')


def Bye():
    print('正在退出...')
    exit(0)


def showDisk():
    pass
    root.lsDisk()


def addDisk():
    name = input("请输入磁盘名:")
    root.createDisk(name)


def showDir():
    root.lsdir()


def addDir():
    root.pwd()
    name=input('请输入目录名:')
    root.mkdir(name)


def delDir():
    name = input('请输入需要删除的目录名:')
    root.delDir(name)
    print(name+'已删除')


def pwd():
    print(root.pwd())


def changedisk():
    name = input("请输入需要切换磁盘的名称:")
    root.changeDisk(name)

def changeDir():
    name=input('请输入需要切换的名录名:')
    root.changeDir(name)

def selectOptions(Op):
    return {'1': showDisk,
            '2': addDisk,
            '3': changedisk,
            '4': showDir,
            '5': addDir,
            '6': delDir,
            '7': pwd,
            '8': changeDir,
            '9': Bye, }.get(Op, '21')


# print('没有这个选项')

if __name__ == '__main__':
    init()
    printMenu()
    Op = 0
    while True:
        Op = input("选择要进行的操作:")
        if 1<=int(Op)<=9:
            selectOptions(Op)()
