def checkNumber(string):
    for x in string:
        if ord('9') < ord(x):  # or ord(x) < ord('0'):
            print('wrong number')
            return checkNumber(input('please try again:'))
    return string


def negativeNmuberCheck(string1, string2):
    # 检测两个数是否都为负数，是的话就执行相加，否则执行减法
    if string1[0] != '-' and string2[0] != '-':
        return bigIntAdd
    else:
        return bigIntSub


def bigIntSub(intOfOne, intOfTwo):
    if intOfOne[0] == '-' and intOfTwo[0] == '-':
        return nagativeIntAdd(intOfOne, intOfTwo)
    else:
        if intOfOne[0] == '-':
            intOfOne, intOfTwo = intOfTwo, intOfOne
        intOfTwo = removeSub(intOfTwo)[::-1]
        intOfOne = intOfOne[::-1]
        lenOfOne = len(intOfOne)
        lenOfTwo = len(intOfTwo)
        flagOfswap = 0
        # if lenOfOne<lenOfTwo:
        if int(intOfOne) < abs(int(intOfTwo)):
            flagOfswap = 1
            lenOfTwo, lenOfOne = lenOfOne, lenOfTwo
            intOfOne, intOfTwo = intOfTwo, intOfOne
            # flagOfZero = 0
        intOfSub = ''
        x = 0
        while x < lenOfTwo:
            if int(intOfTwo[x]) < int(intOfOne[x]):
                intOfSub = intOfSub + str(int(intOfOne[x]) - int(intOfTwo[x]))
                #  flagOfZero = 0
            elif int(intOfTwo[x]) > int(intOfOne[x]):
                # 借位操作
                Subed = x + 1
                while Subed <= lenOfOne and int(intOfOne[Subed]) == 0:
                    intOfOne = repStr(intOfOne, Subed, 9)
                    Subed = Subed + 1
                intOfOne = repStr(intOfOne, Subed, int(intOfOne[Subed]) - 1)
                if intOfOne[-1] == '0':
                    intOfOne = list(intOfOne)
                    intOfOne.pop()
                    intOfOne = ''.join(intOfOne)
                intOfSub = intOfSub + str(int(intOfOne[x]) + 10 - int(intOfTwo[x]))
            else:
                intOfSub = intOfSub + '0'

            x = x + 1
        intOfSub = intOfSub + intOfOne[lenOfTwo::]
        intOfSub = list(intOfSub)
        a = '0'
        while a == '0':
            if intOfSub:
                a = intOfSub.pop()
            else:
                intOfSub = '0'
                break
            if a != '0':
                intOfSub.append(a)
        if flagOfswap:
            sumOfInt = '-' + (''.join(intOfSub))[::-1]
            return addComma(sumOfInt)
        sumOfInt = (''.join(intOfSub))[::-1]
        return addComma(sumOfInt)


def addComma(string):
    string = list(string)
    x = 3
    if string[0] == '-':
        length = len(string) - 1
    else:
        length = len(string)
    while x < length:
        string.insert(x.__neg__(), ',')
        x = x + 4
        length = length + 1
    return (''.join(string))


def repStr(string, x, num):
    l = list(string)
    l[x] = str(num)
    return ''.join(l)


def removeSub(string):
    l = list(string)
    l.remove('-')
    return ''.join(l)


def pushNumber(BigInter, position, Number):
    a = list(BigInter)
    Number = str(Number)
    if a[0] == '-':
        a.insert(position, Number)
    else:
        a.insert(position - 1, Number)
    return ''.join(a)


def delNumber(BigInter, position):
    a = list(BigInter)
    if a[0] == '-':
        a.pop(position)
    else:
        a.pop(position - 1)
    return ''.join(a)


def bigIntAdd(intOfOne, intOfTwo):
    intOfOne = intOfOne[::-1]
    intOfTwo = intOfTwo[::-1]
    lenStrOne = len(intOfOne)
    lenStrTwo = len(intOfTwo)
    if lenStrOne > lenStrTwo:
        intOfOne, intOfTwo = intOfTwo, intOfOne
        lenStrOne, lenStrTwo = lenStrTwo, lenStrOne
    x = 0
    intOfSum = ''
    flagOften = 0
    while x < lenStrOne:
        sum = int(intOfOne[x]) + int(intOfTwo[x]) + flagOften
        if sum < 10:
            flagOften = 0
            intOfSum += str(sum)
            x = x + 1
        else:
            flagOften = 1
            intOfSum += str(sum % 10)
            x = x + 1
    if flagOften == 1:
        if lenStrTwo == lenStrOne:
            intOfTwo += '1'
        x = lenStrOne
        while x < lenStrTwo:
            sum = int(intOfTwo[x]) + 1
            if sum < 10:
                # flagOften = 0
                intOfTwo = repStr(intOfTwo, x, sum)
                break
            else:
                intOfTwo = repStr(intOfTwo, x, sum % 10)
                x = x + 1
                if x >= lenStrTwo:
                    intOfTwo += '1'
    intOfSum = (intOfSum + intOfTwo[lenStrOne::])[::-1]
    return addComma(intOfSum)


def nagativeIntAdd(intOfOne, intOfTwo):
    return '-' + bigIntAdd(removeSub(intOfOne), removeSub(intOfTwo))


print("输入两个整数，每输入一个，键入回车,不要输入+号，默认执行加法运算")
intOfOne = input('please input first number:')
intOfOne = checkNumber(intOfOne)
intOfTwo = input('please input second number:')
intOfTwo = checkNumber(intOfTwo)
operator = negativeNmuberCheck(intOfOne, intOfTwo)  # 创造操作符
print('result:%s' % (operator(intOfOne, intOfTwo)))
# 下面代码测试删除与插入操作
# intOfOne = delNumber(intOfOne, 1)
# print('delete one:%s' % (intOfOne))
# intOfTwo = pushNumber(intOfTwo,1,3)
# print('push three:%s' % (intOfTwo))
# operator = negativeNmuberCheck(intOfOne, intOfTwo)  # 创造操作符
# sumOfInt=operator(intOfOne,intOfTwo)
