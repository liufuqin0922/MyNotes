from Quenu import Queue
def KFib(k,max):
    q=Queue()
    for x in range(k):
        q.enqueue(0)
    Fib=f=0
    q.enqueue(1)
    while True:
        Fib=Fib+q.items[0]-f
        f=q.items[q.size()-1]
        print(f,end=' ')
        q.dequeue()
        q.enqueue(Fib)
        if Fib+q.items[0]-f>max:
            break

    while q.isEmpty()!=True:
        print(q.dequeue(),end=' ')

KFib(10,20)