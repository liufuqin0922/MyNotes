def PrintDigit(integer):
    if integer/10==0:
        return
    PrintDigit(int(integer / 10))
    print(integer % 10,end='')

PrintDigit(12345)