from Minheap import Minheap


class HuffmanNode:
    def __init__(self, data=0, code='', pr=None, left=None, right=None):
        self.data = data
        self.haffmancode = code
        self.leftChild = left
        self.rightChild = right
        self.parent = pr



    def __lt__(self, other):
        return self.data < other.data

    def __eq__(self, other):
        return self.data == other.data

    def __ge__(self, other):
        return self.data >= other.data

    def isleaf(self):
        assert (
            (self.leftChild is None and self.rightChild is None) or (
                self.leftChild is not None and self.rightChild is not None))
        return self.leftChild is None and self.rightChild is None


class HuffmanTree:
    def __init__(self, w=[], n=0):
        self._root = []
        hp = Minheap()
        #tmp = HuffmanNode()
        parent = HuffmanNode()
        for x in range(2 * n - 1):
            self._root.append(HuffmanNode())
        for x in range(n):
            tmp = HuffmanNode()
            tmp.data = w[x + 1]
            hp.insert(tmp)
        for x in range(n - 1):
            fir_temp = hp.remove_min()
            first = fir_temp
            sec_temp = hp.remove_min()
            second = sec_temp
            self._mergetree(first, second, parent)
            hp.insert(parent)

        self._root = parent
        print("       root = ", end='')
        print(self._root.data)
        self.output(self.root, '')
        self._buildcode(self._root, '')

    def _deletetree(self, t):
        if t is not None:
            self._deletetree(t.leftChild)
            self._deletetree(t.rightChild)
            del t

    def _mergetree(self, bt1, bt2, parent):
        parent = HuffmanNode()
        parent.leftChild = bt1
        parent.rightChild = bt2
        bt1.parent=parent
        bt2.parent=parent
        print(hasattr(bt1,'leftChild'))
        if(bt1.leftChild is not None and bt1.leftChild.parent is not bt1):
            bt1.leftChild.parent=bt1
        if bt1.rightChild is not None and bt1.rightChild.parent is not bt1:
            bt1.rightChild.parent=bt1
        if bt2.leftChild is not None and bt2.leftChild.parent is not bt2:
            bt2.leftChild.parent=bt2
        if bt2.rightChild is not None and bt2.rightChild.parent is not bt2:
            bt2.rightChild.parent=bt2
        print(str(bt1.data)+" and "+str(bt2.data)+" union to："+str(parent.data))

    def _buildcode(self, x, s):
        pass

    def output(self, t, str):
        if t:
            return
        print(str, end='')
        print(t.data)
        if t.leftChild:
            print("─┐")
            if t.rightChild:
                self.output(t.leftChild, str + "│　")
            else:
                self.output(t.leftChild, str + "　　")
        if t.rightChild:
            print()
            print(str + "└─┐")
            self.output(t.rightChild, str + "　　")

    @property
    def root(self):
        return self._root
