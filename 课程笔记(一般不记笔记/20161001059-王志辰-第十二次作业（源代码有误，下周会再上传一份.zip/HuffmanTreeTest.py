from  HuffmanTree import HuffmanTree

with open('data.txt', 'r+') as f:
    n = int(f.readline())
    print("there are", n, "nodes in the file.")
    print("The weight of each node is:")
    w = list(map(int, (f.readline().split(' '))))
    w.insert(0, None)
    x = 1
    while x <= n:
        print("weight[", x,"]: ", w[x])
        x=x+1
    htree=HuffmanTree(w,n)