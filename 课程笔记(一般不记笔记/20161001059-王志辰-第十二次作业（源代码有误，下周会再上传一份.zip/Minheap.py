class Minheap:
    def __init__(self, heap=None):
        if heap is None:
            heap = []
        self._heap = list(heap)
        currentSize=self.get_current_size()
        currentPos=(currentSize-2)//2
        while currentPos>=0:
            self._shiftdown(currentPos,currentSize-1)
            currentPos=currentPos-1

    def get_current_size(self):
        return len(self._heap)

    def insert(self, x):
        self._heap.append(x)
        self._shiftup(self.get_current_size() - 1)

    def remove(self, pos):
        x = self._heap[pos]
        self._heap[pos] = self._heap[self.get_current_size() - 1]
        self._heap.pop()
        self._shiftdown(pos, self.get_current_size() - 1)
        return x

    def remove_min(self):
        if self.get_current_size()==0:
            return None
        x = self._heap[0]
        self._heap[0] = self._heap[self.get_current_size() - 1]
        self._heap.pop()
        self._shiftdown(0, self.get_current_size() - 1)
        return x

    def is_empty(self):
        return self._heap==[]

    def make_empty(self):
        self._heap.clear()

    def output(self):
        for x in self._heap:
            print(x,end=' ')
        print()

    def _shiftdown(self, start, end):
        i = start
        j = 2 * start + 1
        temp = self._heap[i]
        while j <= end:
            if (j < end) and (self._heap[j] > self._heap[j + 1]):
                j = j + 1
            if temp <= self._heap[j]:
                break
            else:
                self._heap[i] = self._heap[j]
                i=j
                j=2*j+1
        self._heap[i] = temp

        pass

    def _shiftup(self, start):
        j = start
        i = ((j - 1) // 2)
        temp = self._heap[j]
        while j > 0:
            if self._heap[i] <= temp:
                break
            else:
                self._heap[j] = self._heap[i]
                j = i
                i = (i - 1) // 2
        self._heap[j] = temp
